from .FileManager import *
print("SimpleFileEdit was initialized sucessfully!")